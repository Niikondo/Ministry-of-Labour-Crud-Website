




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!--Bootstrap-->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">

     <title>MILREC</title>
</head>
<body>
<header>
                <nav class="navbar navbar-expand-md navbar-dark" style="background-color: lightGreen">
                    <div>
                        <a href="" class="navbar-brand"Style="color:black"><b>New Record Form </b> </a>
                    </div>

        
                </nav>
            </header>
            <br>
    <div class="container-5 ">
        <h2>Add New Record</h2>
        <form method= "post" >
      <!--  <th>Name of applicatant</th>
                <th>Date Recieved</th>
                <th>Positions</th>
                <th>Number of Positions</th>
                <th>No. of Position Recomended</th>
                <th>No. of Position not Recomended</th>
                <th>Remarks</th>
                <th>Exemption end date</th>-->
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Name of Applicant</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="name" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Date Recieved</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Date Recieved" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Positions</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Positions" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Number of Positions</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Number of Positions" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">No. of Position Recomended</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="No. of Position Recomended" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">No. of Position not Recomended</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="No. of Position not Recomended" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Remarks</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Remarks" value="">
                </div>
                <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Exemption end date</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Exemption end date" value="">
                </div>
            </div>
            <div class= "row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="officeA110.php" role="button">Cancel</a>
            </div>
        </form>
    
</body>
</html>