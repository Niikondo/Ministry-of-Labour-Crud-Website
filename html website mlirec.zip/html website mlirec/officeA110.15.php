<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Bootstrap-->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">

    <title>MILREC</title>
</head>
<body>
<header>
                <nav class="navbar navbar-expand-md navbar-dark" style="background-color: lightGreen">
                    <div>
                        <a href="year2.php" class="navbar-brand"Style="color: lightblack"><b>Exit </b> </a>
                    </div>

        
                </nav>
            </header>
            <br>
    <div class="container my-5">
        <h2> Records of Clients</h2>
        <a class="btn btn-primary" href="createA110.php" role="button">Add New Record</a>
        <br>
        <table class="table">
            <thread>
             <tr>
                <th>Organization</th>
                <th>Date Recieved</th>
                <th>Department/Division</th>
                <th>Aproval Period</th>
                <th>Exempted Section</th>
                <th>Date Sign by the Minister</th>
                <th>Requested</th>
             </tr>
            </thread>
            <tbody>
                
                <?php
                /*
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = " to be";

                //create connection
                $connection = new mysqli($servername,$username,$password,$database);

                //Check connection
                if ($connection->connect_error) {
                    die("connection on fail: " . $connection->connect_error);        
                }
                    //read all row from database table
                    $sql = "SELECT * FROM Penehafo";
                    $result = $connection->query($sql);

                    if (!result){
                        die("Invalid query: " .$connection->error);

                    }
                    //rad the data of each row
                    while($row = $result->fetch_assoc()){
                     echo"<tr>
                     <td>$row[Organization]</td>
                     <td>$row[DateRecieved]</td>
                     <td>$row[Department/Division]</td>
                     <td>$row[AprovalPeriod]</td>
                     <td>$row[ExemptedSection]</td>
                     <td>$row[DateSignbytheMinister]</td>
                     <td>$row[Requested]</td>
                     <td>
                         <a class='btn btn-primary btn-sm' href='edit,php?Organization=$row[Organization]'>Edit</a>
                         <a class='btn btn-danger btn-sm' href='delete.php?Organization=$row[Organization]'>delete</a>
                     </td>
                 
                     </tr>
                     ";   
                    }
*/
                ?>
                
                <!--
                <tr>
                <td>mistry of labour</td>
                <td>23/06/22</td>
                <td>Work and Transport</td>
                <td>3month</td>
                <td>none</td>
                <td>11 may</td>
                <td>Requested Today</td>
                <td>
                    <a class='btn btn-primary btn-sm' href=''>Edit</a>
                    <a class='btn btn-red btn-sm' href=''>delete</a>
                </td>
            
                </tr>
                -->
            </tbody>
        </table> 
    </div>   
                 
</body>
</html>