<!DOCTYPE html>
<html lang="en" style="background-size:100%;overflow: hidden;background-color:lightgrey">
        <head>
            
            <title>MLIREC OVERTIME APPLICATION</title>
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>


        <body >
            <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-light" >
                <a class="navbar-brand"style="margin-left:450px" href="#">MLIREC</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                    <a class="nav-item nav-link active" style="margin-left:10px" href="index.php">Home <span class="sr-only">(current)</span></a>
                    
                    </div>
                </div>
                </nav>
            </header>
            <br>
            <body style= >
            
           
            <br>

            <div class="row">
               

                <div class="container">
                    <h3 class="text-center"><b>MLIREC IRA DATABASE</a></h3>
                    <hr>
                    <br />
                     <div class="container text-left">
                        <a href="loginA222.php" class="btn btn-secondary" Style="color: white;width:400px; height:60px; font-size:20px"><b>Exemption_AA Act & Variation</b></a>
                    </div>
                    <br>
                    <br>
                    <div class="container text-left">

                        <a href="loginA110.php" class="btn btn-secondary" Style="color: white ;width:400px; height:60px; font-size:20px"><b>Exemption_Labour Act</b></a> 
                    </div>
                    <br>
                    <br>
                    
                   <div class="container text-left">

                        <a href="loginA111.php" class="btn btn-secondary" Style="color: white;width:400px; height:60px; font-size:20px"><b>Appointment_Conciliators/Arbitrators</b></a>
                    </div>
                   
                    
                           
                            
                        </tbody>

                    </table>
                     
                </div>
            </div>
            
        </body>
        <hr>
        <br><br>

        <footer>
  <p Style=" position: fixed;
            padding: 10px 10px 0px 10px;
            bottom: -20px;
            width: 100%;
            height: 40px;
            background: white;
            text-align: center;">Copyright ©2022 MLIREC All Rights Reserved</p>
  
</footer>
        </html>

