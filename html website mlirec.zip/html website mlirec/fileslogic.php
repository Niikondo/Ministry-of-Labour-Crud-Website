<?php
if (isset($_POST['save'])|| isset($filename)) { // if save button on the form is clicked
                // name of the uploaded file
            $filename = $_FILES['filename']['name'];
            $conn = mysqli_connect('localhost', 'root', '', 'iramol');
          

$sql = "SELECT * FROM A22215";
$result = mysqli_query($conn, $sql);
                // destination of the file on the server
                $destination = 'uploads/' . $filename;
            
            
                // get the file extension
                $extension = pathinfo($filename, PATHINFO_EXTENSION);
            
                // the physical file on a temporary uploads directory on the server
                $file = $_FILES['filename']['tmp_name'];
                $size = $_FILES['filename']['size'];

            
                if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
                    echo "You file extension must be .zip, .pdf or .docx";
                } elseif ($_FILES['filename']['size'] > 1000000) { // file shouldn't be larger than 1Megabyte
                    echo "File too large!";
                } else {
                    // move the uploaded (temporary) file to the specified destination
                    print_r($destination);
                    if (move_uploaded_file($file, $destination )) {
                        echo "File uploaded successfully";

                    } else {
                        echo "Failed to upload file.";
                    }
                }
            }
            ?>