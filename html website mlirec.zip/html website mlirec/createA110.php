




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!--Bootstrap-->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">

     <title>MILREC</title>
</head>
<body>
<header>
                <nav class="navbar navbar-expand-md navbar-dark" style="background-color: lightGreen">
                    <div>
                        <a href="" class="navbar-brand"Style="color:black"><b>New Record Form </b> </a>
                    </div>

        
                </nav>
            </header>
            <br>
    <div class="container-5 ">
        <h2>Add New Record</h2>
        <form method= "post" >
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Organization</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="name" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Date Recieved</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Date Recieved" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Department/Division</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Department/Division" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Aproval Period</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Aproval Period" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Expempted Section</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Expempted Section" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Date signed by the Minister</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Date signed by the Minister" value="">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Requested</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Requested" value="">
                </div>
            </div>
            <div class= "row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        
                <div class="col-sm-3 d-grid">
                    <a class="btn btn-outline-primary" href="officeA110.php" role="button">Cancel</a>
            </div>
        </form>
    
</body>
</html>