<!DOCTYPE html>
<html>
<?php
$user = 'root';
$password = '';

$database = 'IRAMOL';

$servername ='localhost';
$mysqli = new mysqli($servername,$user,$password, $database);

 
// Checking for connections
if ($mysqli->connect_error) {
    die('Connect Error (' .
    $mysqli->connect_errno . ') '.
    $mysqli->connect_error);
}
 
// SQL query to select data from database
$sql = " SELECT * FROM A22219 ";
$result = $mysqli->query($sql);
$mysqli->close();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Bootstrap-->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
   <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

    <title>MILREC</title>
</head>
<body background=""style="background-size:100%;background-color:lightGrey">
<header>
            <nav class="navbar navbar-expand-lg navbar-light bg-light" >
                <a class="navbar-brand"style="margin-left:450px" href="#">MLIREC</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                    <a class="nav-item nav-link active" style="margin-left:10px" href="index.php">Home <span class="sr-only"></span></a>
                    
                    </div>
                </div>
                </nav>
            </header>
            
            
</head>
<body>
    <?php require_once 'process.php';?>
    <?php 

    if (isset($_SESSION['message'])): ?>
    <div style="position:fixed;margin-left:800px" class="alert alert-warning alert-dismissible fade show role='alert'<?=$_SESSION['msg_type']?>">

    <?php
    echo $_SESSION['message'];
    unset($_SESSION['message']);
    ?>
    </div>
    <?php endif ?>
        
    <div class="container my-5" style="height:50px">
    <a href="years.php" class="btn btn-secondary" Style="color: white;margin-left:-200px"><b><</b></a>
        <h2 style=text-align:center>Records of Clients For The Year 2019</h2>
        <hr>
        <br>
        <div  style="margin-left:-200px; display: inline-block;" >
        <a class="btn btn-secondary" style="margin-left:"  href="createA222.19.php" role="button">Add New Record</a>
        <input type="text" id="myInput" style="margin-left:;width:300px;border-width:4px"  onkeyup="myFunction()" placeholder="Search by Name of Applicant" title="Type in Name of Applicant" style="width:300px">
        <a class="btn btn-danger" style="margin-left:1690px"  href="csvA222.19.php" role="button">Download</a>
    </div>
        <main>


</main>
	<link rel="stylesheet" type="text/css" href="style.css"/>
        <br>

        
        <table  class="table" table id="myTable" style="background-color:lightgrey;
border:black; border-width:4px;border-style:solid;background:lightgrey;border-radius: 15px; width:1800px; margin-left:-200px">
            <thread>
             <tr style="background-color: lightgrey">
                <th>Name of Applicant</th>
                <th>Date Received</th>
                <th>Positions</th>
                <th>Number of Positions</th>
                <th>No of Positions Recommended</th>
                <th>No of Positions not Recommended</th>
                <th>Remarks</th>
                <th>Exemption_end_date</th>
               
             </tr>
            </thread>
            <tbody>
                
                <?php
                while ($rows=$result->fetch_assoc())
                {
        ?>
       <tr>
               
                <td><?php echo $rows['Name_of_Applicant'];?></td>
                <td><?php echo $rows['Date_Received'];?></td>
                <td><?php echo $rows['Positions'];?></td>
                <td><?php echo $rows['Number_of_Positions'];?></td>
                <td><?php echo $rows['No_of_Positions_Recommended'];?></td>
                <td><?php echo $rows['No_of_Positions_not_Recommended'];?></td>
                <td><?php echo $rows['Remarks'];?></td>
                <td><?php echo $rows['Exemption_end_date'];?></td>
                <td>
                <a href="editA22219.php?ID=<?php echo $rows['ID'];?>"class="btn btn-secondary">Edit</a>
                    
                    <a href="processA22219.php?delete=<?php echo $rows['ID'];?>"
                    class="btn btn-danger">Delete</a>
                </td>
                <?php
					include('connA222.php');
					$query=mysqli_query($conn,"select * from `A22219`");
					while($row=mysqli_fetch_array($query)){
						?>

                        

                <td>
            
                     </td>


            </tr
            <?php } ?>
            <?php } ?>    
                  

           
   
                -->
            </tbody>
        </table> 
    </div>   
                 
</body>
<footer>
  <p Style=" position: fixed;
            padding: 10px 10px 0px 10px;
            bottom: -20px;
            width: 100%;
            height: 40px;
            background: white;
            text-align: center;">Copyright ©2022 MLIREC All Rights Reserved</p>
  
</footer>
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</html>