<?php

if(isset($_POST["formValues"]) && !empty($_POST["formValues"])){
    $formData= json_decode($_POST["formValues"]);
    $fileData='';
    var_dump($_FILES);
    if(isset($_POST["fileUpload"]) && !empty($_POST["fileUpload"])){
        $fileData= json_decode($_POST["fileUpload"]);
    }
    var_dump($_FILES);
    print_r($fileData);
    echo '200';
    //print_r($dataArray);
}
?>