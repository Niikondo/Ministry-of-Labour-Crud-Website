<!DOCTYPE html>
<hml>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <html>

       <!-- <head>-->
       <style>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    * {
      box-sizing: border-box;
    }
    
    /* Create two equal columns that floats next to each other */
    .column {
      float: left;
      width: 50%;
      padding: 10px;
    }
    
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    /* Style the buttons */
    .btn {
      border: none;
      outline: none;
      padding: 12px 16px;
      background-color: #f1f1f1;
      cursor: pointer;
    }
    
    .btn:hover {
      background-color: #ddd;
    }
    
    .btn.active {
      background-color: #666;
      color: white;
    }
    </style>
            <title>MLIREC OVERTIME</title>
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        </head>

        <body style="background-size:100%;background-color:lightGrey">

        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-light" >
                <a class="navbar-brand"style="margin-left:450px" href="#">MLIREC</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                    <a class="nav-item nav-link active" style="margin-left:10px" href="index.php">Home <span class="sr-only">(current)</span></a>
                    
                    </div>
                </div>
                </nav>
            </header>
            <br>
            <br>
            <br>
            <title>IRA DATABASE</title>
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        </head>

        <body style="background-size:100%;background-color:lightGrey">

            <header>
               
                   <div class="container">
                    <h3 class="text-center"><b>Years Exemption_Labour Act</a></h3>
                    <hr>
                    <br>
                    </div>
            </header>
            <br>
            <br>
            <br>
            <div class="container col-md-5">

             <div class="container text-left" style="width:5000px;border-radius: 15px;border-style:solid;background:lightgrey;margin-left:-150px;">
<div class="row">
  <div class="column" style="background-color:#aaa;">
    <h2>  <div class="container text-left">

    <a href="officeA110.15.php" class="btn btn-secondary" Style="color: white"><b>2015</b></a>
                    </div></h2>

  </div>
  <div class="column" style="background-color:#bbb;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.16.php" class="btn btn-secondary" Style="color: white"><b>2016</b></a>
                    </div></h2>
  
  </div>
</div>

<div class="row">
  <div class="column" style="background-color:#ccc;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.17.php" class="btn btn-secondary" Style="color: white"><b>2017</b></a>
                    </div></h2>
   
  </div>
  <div class="column" style="background-color:#aaa;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.18.php" class="btn btn-secondary" Style="color: white"><b>2018</b></a>
                    </div></h2>

  </div>
   <div class="column" style="background-color:#bbb;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.19.php" class="btn btn-secondary" Style="color: white"><b>2019</b></a>
                    </div></h2>

  </div>
   <div class="column" style="background-color:#ccc;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.20.php" class="btn btn-secondary" Style="color: white"><b>2020</b></a>
                    </div></h2>

  </div>
   <div class="column" style="background-color:#aaa;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.21.php" class="btn btn-secondary" Style="color: white"><b>2021</b></a>
                    </div></h2>

  </div>
   <div class="column" style="background-color:#bbb;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.22.php" class="btn btn-secondary" Style="color: white"><b>2022</b></a>
                    </div></h2>

  </div>
   <div class="column" style="background-color:#ccc;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.23.php" class="btn btn-secondary" Style="color: white"><b>2023</b></a>
                    </div></h2>

  </div>
   <div class="column" style="background-color:#aaa;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.24.php" class="btn btn-secondary" Style="color: white"><b>2024</b></a>
                    </div></h2>

  </div>
   <div class="column" style="background-color:#bbb;">
    <h2>  <div class="container text-left">

                        <a href="officeA110.25.php" class="btn btn-secondary" Style="color: white"><b>2025</b></a>
                    </div></h2>

  </div>
</div>
</div></div></div></div></div></div></div>
<footer>
  <p Style=" position: fixed;
            padding: 10px 10px 0px 10px;
            bottom: -20px;
            width: 100%;
            height: 40px;
            background: white;
            text-align: center;">Copyright ©2022 MLIREC All Rights Reserved</p>
  
</footer>
</html>