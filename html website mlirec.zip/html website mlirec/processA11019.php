<?php
session_start();
$mysqli = new mysqli('localhost', 'root','','IRAMOL') or die (mysqli_error($mysqli));


 if (isset($_GET['delete'])){
    $ID = $_GET['delete'];
    $mysqli->query("DELETE FROM A11019 WHERE ID=$ID") or die($mysqli->error());

    $_SESSION['message'] = "Record has  been deleted!!";
    $_SESSION['msg_type'] = "denger";
    header("location:OFFICEa110.19.php");
 }